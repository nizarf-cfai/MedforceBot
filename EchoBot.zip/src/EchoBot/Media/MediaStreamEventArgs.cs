﻿using Microsoft.Skype.Bots.Media;

namespace EchoBot.Media
{
    public class MediaStreamEventArgs
    {
        public List<AudioMediaBuffer> AudioMediaBuffers { get; set; }
    }
}
