﻿using Microsoft.Skype.Bots.Media;

namespace EchoBot.Bot
{
    public interface IBotMediaLogger : IMediaPlatformLogger
    {
    }
}
